<?php
// Define database credentials
define('DB_HOST', getenv('DB_HOST') ?: 'mysql');
define('DB_USER', getenv('DB_USER') ?: 'webuser');
define('DB_PASS', getenv('DB_PASS') ?: 'webpass');
define('DB_NAME', getenv('DB_NAME') ?: 'di_internet_technologies_project');
?>